# Whatsupp

**Whatsupp** is an offline Android chat mockup studio. It recreates a familiar WhatsApp-inspired dark chat interface for composing fictional conversations, not for communicating with real contacts.

## What is implemented

- Local contact book with manual contacts and an Android phone-contact picker.
- Custom display name, phone number, about/status and profile photo.
- Contact information screen with avatar, profile details, media strip and local settings.
- One-to-one chat screen with incoming and outgoing message bubbles.
- Message editor for sender, body, date, time, media, delivery/read status and reply target.
- Edit, reply, delete and emoji reactions for messages.
- Export the visible chat screen as a PNG through Android’s Save As picker.
- Local image/video/audio/file attachment picker.
- Chat list, contact and in-chat message search, bottom navigation and app settings.
- Room database storage; contacts and conversations remain on this device.

## Safety boundary

The app does **not** connect to WhatsApp, SMS, RCS, phone calls or any messaging provider. It does not declare `INTERNET`, `SEND_SMS`, `CALL_PHONE` or `READ_CALL_LOG`. The call/video/payment icons are informational mock controls and do not launch phone/payment apps. Chat actions only write to the local Room database. A visible `SIMULATED CHAT` indicator appears in every conversation.

The Android phone-contact picker is only used when the user explicitly chooses **Phone contacts**; it imports the selected contact's display name, phone number and available photo URI into Whatsupp's local database. The system photo picker is used for custom avatars and attachments. Updates, Communities and Calls tabs are visual placeholders; no real calls, updates or communities are created.

## Build locally

Requires JDK 17, Gradle 8.9 and Android SDK Platform 35 / Build Tools 35.0.0.

```bash
gradle testDebugUnitTest
gradle assembleDebug
```

Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

`.github/workflows/android.yml` provisions Gradle 8.9 and runs on pushes to `main` / `master` and on manual `workflow_dispatch`. It runs unit tests, builds the debug APK, and uploads it as an Actions artifact.

For a stable install-over-existing release APK, configure these repository Actions secrets:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Once all four secrets are set, the workflow signs the release APK using the same keystore on every run and publishes a versioned GitHub Release marked as latest. Never rotate or lose the keystore if you need future APKs to update an already-installed copy.

See [SIGNING_SETUP.md](SIGNING_SETUP.md) for setting up the stable signing key.
